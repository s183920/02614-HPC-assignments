#ifndef _MATRIX_INIT_TEST_H
#define _MATRIX_INIT_TEST_H


void init_grid_matrices(double ***F, double ***U, int N, double start_T);

#endif